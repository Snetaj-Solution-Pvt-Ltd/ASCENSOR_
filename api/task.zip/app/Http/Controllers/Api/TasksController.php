<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TasksController extends Controller
{
    public function create(Request $request) {
        try {
            $validateReq = Validator::make($request->all(), 
            [
                'title' => 'required',
                'description' => 'required',
                'deadline' => 'required|date_format:Y-m-d',
                'category_id' => 'required|integer',
            ]);

            if($validateReq->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateReq->errors()
                ], 401);
            }

            
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
